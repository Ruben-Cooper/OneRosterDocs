#! /bin/bash

mysql --user=root --password=$MYSQL_ROOT_PASSWORD --database=$MYSQL_DATABASE