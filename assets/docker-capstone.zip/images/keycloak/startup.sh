#!/bin/bash

/opt/bitnami/keycloak/bin/kcadm.sh create roles -s name=catadmin-admin -r master --no-config --server http://localhost:8080/auth --realm master --user $KEYCLOAK_ADMIN_USER --password $KEYCLOAK_ADMIN_PASSWORD
/opt/bitnami/keycloak/bin/kcadm.sh create roles -s name=catadmin-student -r master --no-config --server http://localhost:8080/auth --realm master --user $KEYCLOAK_ADMIN_USER --password $KEYCLOAK_ADMIN_PASSWORD