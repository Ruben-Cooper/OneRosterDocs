<?php  // Moodle configuration file

unset($CFG);
global $CFG;
$CFG = new stdClass();

// #################################################################################################################################
// # Main database configuration
// #################################################################################################################################
$CFG->dbtype    = 'pgsql';
$CFG->dbhost    = 'capstone-moodle-db';
$CFG->dblibrary = 'native';
$CFG->dbname    = 'moodle';
$CFG->dbuser    = 'moodle_user';
$CFG->dbpass    = 'password';
$CFG->prefix    = 'mdl_';
$CFG->dboptions =  array (
  'dbpersist'   => 0,
  'dbport'      => '',
  'dbsocket'    => '',
);

// #################################################################################################################################
// # PHPUnit database configuration
// #################################################################################################################################
$CFG->phpunit_dbtype    = 'pgsql';
$CFG->phpunit_dbhost    = 'moodle-db';
$CFG->phpunit_dblibrary = 'native';
$CFG->phpunit_dbname    = 'moodle';
$CFG->phpunit_dbuser    = 'moodle_user';
$CFG->phpunit_dbpass    = 'password';
$CFG->phpunit_prefix    = 'phpu_';

// #################################################################################################################################
// # Dataroot configurations
// #################################################################################################################################
$CFG->wwwroot              = 'https://moodle.localhost';
$CFG->dataroot             = '/var/lib/sitedata';
$CFG->behat_dataroot       = '/var/lib/behatdata';
$CFG->phpunit_dataroot     = '/var/lib/phpunitdata';
$CFG->directorypermissions = 0777;

// #################################################################################################################################
// # Debugging configurations
// #################################################################################################################################
$CFG->debug           = (E_ALL | E_STRICT); // DEBUG_DEVELOPER
$CFG->debugdisplay    = 1;
$CFG->debugstringids  = 1; // Add strings=1 to url to get string ids.
$CFG->perfdebug       = 15;
$CFG->debugpageinfo   = 1;

// #################################################################################################################################
// # Email configurations
// #################################################################################################################################
$CFG->smtphosts      = 'capstone-mailhog:1025';
$CFG->noreplyaddress = 'noreply@moodle.com';


// #################################################################################################################################
// # Moodle proxy configuration
// #################################################################################################################################
$CFG->proxyhost = 'capstone-squid';
$CFG->proxyport = 3128;
$CFG->proxytype = 'HTTP';

require_once(__DIR__ . '/lib/setup.php');