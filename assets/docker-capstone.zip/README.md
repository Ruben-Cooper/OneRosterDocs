To get it working clone moodle in to `./sites/moodle`
```
git clone git@github.com:moodle/moodle.git sites/moodle
```

Then copy the `./config.php` into `./sites/moodle/config.php`
```
cp ./config.php .sites/moodle/config.php
```

And start all the services using docker-compose
```
docker-compose up -d
```